package main

import (
    "golang.org/x/net/websocket"
    "fmt"
    "log"
    "net/http"
    "sync"
    "encoding/json"
)

var USERS_LIST map[*websocket.Conn]string


func Echo(ws *websocket.Conn) {
    var err error
    var m = &sync.Mutex{}

    // Associer la websocket de l'user qui vient de se connecter a un nom 
    // Stocker les messages et les noms d'utilisateurs dans une liste ?
    // Si il y a des utilisateurs dans la liste envoyer tout les messages
    // Lorsque qu'un utilisateur se deconnecte le supprimer de la liste (a faire avant la boucle)

    for {
        var reply string

        fmt.Println(len(USERS_LIST))

        err = websocket.Message.Receive(ws, &reply);
        if err != nil {
            fmt.Println("Can't receive")
            break
        } 

        // JSON DECODE DE LA SOCKET + VERIFICATION SI C'EST UN NOUVEL UTILISATEUR

        type Response struct {
            Recognizer string
            Msg string
        }

        r := &Response{}
        err := json.Unmarshal([]byte(reply), &r)
        if err != nil {
            panic(err)
        }

        if r.Recognizer == "newuser" {
            m.Lock()
            USERS_LIST[ws] = r.Msg
            m.Unlock()

    
            resforclient := &Response{
                "newuser",
                r.Msg,
            }

            resjsonify, err := json.Marshal(resforclient)
            
            for userws := range USERS_LIST {
                
                fmt.Println(resjsonify)
                err = websocket.Message.Send(userws, resjsonify);
                if err != nil {
                    fmt.Println("Can't send")
                    break
                } 
            }
        } 
        
        // fmt.Println(reply)
        // fmt.Println("Received back from client: " + reply)
       
        
        // Réponse au client
        // fmt.Println("Sending to client: " + msg)
        // msg := "Received:  " + reply

        // for _, userws := range LIST {
        //     err = websocket.Message.Send(userws, msg);
        //     if err != nil {
        //         fmt.Println("Can't send")
        //         // break
        //     } 
        // }

        
        
        
    }





}

// func register(userwebsocket *websocket.Conn) {
//     var LIST []*websocket.Conn
//     var m = &sync.Mutex{}

//     m.Lock()
//     LIST = append(LIST, userwebsocket)
//     m.Unlock()
//     fmt.Printf("%v", LIST)
//     break
// }

func main() {
    USERS_LIST = make(map[*websocket.Conn]string)
    http.Handle("/", websocket.Handler(Echo))

    if err := http.ListenAndServe(":8000", nil); err != nil {
        log.Fatal("ListenAndServe:", err)
    }
}